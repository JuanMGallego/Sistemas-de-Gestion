﻿namespace Mandaloriano3.Models.Entities
{
    public class Mision
    {
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Recompensa { get; set; }
    }
}
